(function () {
  const config = __CONFIG__;
  const id = '__glass_browser_style_v1';
  let style = document.getElementById(id);
  if (!config.enabled) { if (style) style.remove(); return; }
  if (!style) { style = document.createElement('style'); style.id = id; (document.head || document.documentElement).appendChild(style); }
  const color = config.dark ? '#111111' : '#ffffff';
  const shadow = config.dark ? '0 0 2px #fff,0 0 4px #fff' : '0 1px 2px #000,0 0 3px #000,0 0 5px #000';
  let media = 'img,video,canvas {opacity:' + config.opacity + ' !important;}';
  if (config.mode === 1) media = 'img,video,canvas {opacity:1 !important;clip-path:polygon(evenodd,-2px -2px,calc(100% + 2px) -2px,calc(100% + 2px) calc(100% + 2px),-2px calc(100% + 2px),-2px -2px,0 0,0 100%,100% 100%,100% 0,0 0) !important;outline:1px solid ' + color + ' !important;}';
  if (config.mode === 2) media = 'img,video,canvas {visibility:hidden !important;}';
  style.textContent = `
    html,body,body * {background-color:transparent !important;background-image:none !important;box-shadow:none !important;backdrop-filter:none !important;-webkit-backdrop-filter:none !important;}
    body *,body {color:${color} !important;text-shadow:${shadow} !important;border-color:rgba(150,150,150,.18) !important;}
    body *::before,body *::after {background-color:transparent !important;background-image:none !important;box-shadow:none !important;}
    input,textarea,select,[role="dialog"],[role="menu"] {background-color:rgba(30,30,30,.55) !important;color:white !important;}
    svg {color:${color} !important;}
    ${media}
  `;
})();
