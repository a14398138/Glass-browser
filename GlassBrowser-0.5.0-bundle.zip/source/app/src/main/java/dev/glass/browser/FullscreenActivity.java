package dev.glass.browser;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.*;
import android.widget.*;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class FullscreenActivity extends Activity {
    private WebView web;
    private LinearLayout controls;
    private EditText address;
    private TextView status, nativeTest;
    private Button toggle, media, ink;
    private boolean enabled=true, dark=false;
    private int mediaMode=0, opacity=20;
    private String injection;
    private final String[] mediaNames={"画像: 薄く", "画像: 枠", "画像: 非表示"};

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setBackgroundDrawableResource(android.R.color.black);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setNavigationBarContrastEnforced(false);
        enabled=getSharedPreferences("MainActivity",0).getBoolean("enabled",true);
        dark=getSharedPreferences("MainActivity",0).getBoolean("dark",false);
        mediaMode=getSharedPreferences("MainActivity",0).getInt("media",0);
        opacity=getSharedPreferences("MainActivity",0).getInt("opacity",20);
        injection=asset("overlay.js");
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(0xff111923);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        setContentView(root);
        LinearLayout top=new LinearLayout(this);
        Button menu=button("☰",v->controls.setVisibility(controls.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
        menu.setContentDescription("操作パネルを開閉"); top.addView(menu,new LinearLayout.LayoutParams(dp(48),dp(42)));
        status=new TextView(this); status.setTextSize(12); status.setGravity(17); status.setTextColor(Color.WHITE); status.setShadowLayer(3,0,1,Color.BLACK);
        top.addView(status,new LinearLayout.LayoutParams(0,dp(42),1)); root.addView(top);
        controls=new LinearLayout(this); controls.setOrientation(1); controls.setBackgroundColor(0xCC202630); root.addView(controls);
        LinearLayout urlRow=new LinearLayout(this);
        address=new EditText(this); address.setSingleLine(true); address.setTextColor(Color.WHITE); address.setHintTextColor(0xffcccccc); address.setHint("https://x.com"); address.setTextSize(14); address.setInputType(17);
        address.setImeOptions(2); address.setOnEditorActionListener((v,action,event)->{navigate();return true;});
        urlRow.addView(address,new LinearLayout.LayoutParams(0,dp(48),1)); urlRow.addView(button("開く",v->navigate())); controls.addView(urlRow);
        HorizontalScrollView scroll=new HorizontalScrollView(this); LinearLayout actions=new LinearLayout(this); scroll.addView(actions); controls.addView(scroll);
        actions.addView(button("小窓に戻す",v->returnToOverlay()));
        actions.addView(button("戻る",v->{if(web.canGoBack())web.goBack();}));
        actions.addView(button("X",v->open("https://x.com")));
        actions.addView(button("デモ",v->demo()));
        toggle=button("",v->{enabled=!enabled;apply();}); actions.addView(toggle);
        media=button("",v->{mediaMode=(mediaMode+1)%3;apply();}); actions.addView(media);
        ink=button("",v->{dark=!dark;apply();}); actions.addView(ink);
        actions.addView(button("文字テスト",v->{boolean show=nativeTest.getVisibility()!=View.VISIBLE;nativeTest.setVisibility(show?View.VISIBLE:View.GONE);web.setVisibility(show?View.GONE:View.VISIBLE);status.setText(show?"ネイティブ透過テスト":"Web表示");}));
        actions.addView(button("再読込",v->web.reload()));
        LinearLayout sliderRow=new LinearLayout(this); TextView label=new TextView(this);label.setTextColor(Color.WHITE);label.setText("画像の濃さ");label.setPadding(dp(8),0,0,0);sliderRow.addView(label);
        SeekBar slider=new SeekBar(this);slider.setMax(100);slider.setProgress(opacity);sliderRow.addView(slider,new LinearLayout.LayoutParams(0,dp(40),1));controls.addView(sliderRow);
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} public void onProgressChanged(SeekBar s,int p,boolean user){opacity=p;if(user)apply();}});
        FrameLayout content=new FrameLayout(this);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        web=new WebView(this);web.setBackgroundColor(Color.TRANSPARENT);content.addView(web,new FrameLayout.LayoutParams(-1,-1));
        nativeTest=new TextView(this);nativeTest.setText("透明ウィンドウの確認\n\nこの文字の後ろに動画が見えれば、Android側の透過は成功です。\n\n見えない場合はWebページ以外の層が背景を塗っている可能性があります。\n\n上の ☰ で操作パネルを隠せます。\n「文字テスト」をもう一度押すと戻ります。");nativeTest.setTextSize(20);nativeTest.setPadding(dp(16),dp(24),dp(16),0);nativeTest.setVisibility(View.GONE);content.addView(nativeTest,new FrameLayout.LayoutParams(-1,-1));
        WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setMediaPlaybackRequiresUserGesture(true);
        CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){String scheme=req.getUrl().getScheme();if("https".equals(scheme)||"http".equals(scheme))return false;Toast.makeText(FullscreenActivity.this,"この試作はWebページのみ開けます",Toast.LENGTH_SHORT).show();return true;}
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon){status.setText("読込中…");if(!url.startsWith("https://glass.invalid"))address.setText(url);}
            @Override public void onPageCommitVisible(WebView v,String url){apply();}
            @Override public void onPageFinished(WebView v,String url){apply();status.setText("Glass • "+(enabled?"透過ON":"通常表示"));}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())status.setText("読込失敗: "+e.getDescription());}
        });
        android.os.Bundle incoming=saved==null?BrowserSession.take():saved.getBundle("webState");
        if(incoming==null||web.restoreState(incoming)==null)demo();
        root.post(()->{android.os.ResultReceiver ack=getIntent().getParcelableExtra("overlayAck");if(ack!=null){ack.send(1,android.os.Bundle.EMPTY);getIntent().removeExtra("overlayAck");}});
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private Button button(String title,View.OnClickListener listener){Button b=new Button(this);b.setText(title);b.setTextSize(12);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(10),0,dp(10),0);b.setTextColor(Color.WHITE);b.setBackgroundColor(0xCC27303A);b.setOnClickListener(listener);return b;}
    private String asset(String name){try(InputStream in=getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);return out.toString("UTF-8");}catch(Exception e){throw new IllegalStateException(e);}}
    private void navigate(){String u=address.getText().toString().trim();if(u.isEmpty())return;if(!u.contains(":"))u="https://"+u;Uri parsed=Uri.parse(u);if(!"https".equals(parsed.getScheme())||parsed.getHost()==null){Toast.makeText(this,"https:// のURLを入力してください",Toast.LENGTH_SHORT).show();return;}open(u);}
    private void open(String url){nativeTest.setVisibility(View.GONE);web.setVisibility(View.VISIBLE);web.loadUrl(url);((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);web.requestFocus();}
    private void demo(){nativeTest.setVisibility(View.GONE);web.setVisibility(View.VISIBLE);address.setText("");web.loadDataWithBaseURL("https://glass.invalid/",asset("demo.html"),"text/html","UTF-8",null);}
    private void apply(){
        toggle.setText(enabled?"透過ON":"透過OFF");media.setText(mediaNames[mediaMode]);ink.setText(dark?"文字: 黒":"文字: 白");
        nativeTest.setTextColor(dark?Color.BLACK:Color.WHITE);nativeTest.setShadowLayer(3,0,1,dark?Color.WHITE:Color.BLACK);
        getSharedPreferences("MainActivity",0).edit().putBoolean("enabled",enabled).putBoolean("dark",dark).putInt("media",mediaMode).putInt("opacity",opacity).apply();
        try{JSONObject c=new JSONObject();c.put("enabled",enabled);c.put("dark",dark);c.put("mode",mediaMode);c.put("opacity",opacity/100.0);web.evaluateJavascript(injection.replace("__CONFIG__",c.toString()),null);}catch(Exception e){status.setText("表示調整に失敗");}
    }
    private boolean returning;
    private void returnToOverlay(){
        if(returning)return;
        if(!android.provider.Settings.canDrawOverlays(this)){Toast.makeText(this,"他のアプリの上に表示する権限を許可してください",Toast.LENGTH_LONG).show();return;}
        returning=true;BrowserSession.capture(web);
        android.os.ResultReceiver result=new android.os.ResultReceiver(new android.os.Handler(android.os.Looper.getMainLooper())){
            @Override protected void onReceiveResult(int code,Bundle data){returning=false;if(code==1)finishAndRemoveTask();else Toast.makeText(FullscreenActivity.this,"小窓を開始できませんでした",Toast.LENGTH_LONG).show();}
        };
        try{startForegroundService(new android.content.Intent(this,BrowserService.class).putExtra("result",result));}
        catch(RuntimeException e){returning=false;Toast.makeText(this,"小窓を開始できませんでした",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);Bundle b=new Bundle();web.saveState(b);out.putBundle("webState",b);}
    @Override public void onBackPressed(){if(nativeTest.getVisibility()==View.VISIBLE){nativeTest.setVisibility(View.GONE);web.setVisibility(View.VISIBLE);}else if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
    @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
