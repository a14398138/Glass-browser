package dev.glass.browser;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.widget.FrameLayout;

/** Native transparent chrome; no screen capture or opaque content background. */
final class GlassFrame extends FrameLayout {
    interface Gestures { void start(int region,float x,float y); void move(float x,float y); void end(float x,float y,boolean cancel); }
    static final int MOVE=1, TL=2, TR=3, BL=4, BR=5, BAR=6;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip=new Path(),ring=new Path();
    private final float density;
    private final Gestures gestures;
    private int active, pointer=-1;
    GlassFrame(Context context,Gestures gestures) {super(context);this.gestures=gestures;density=getResources().getDisplayMetrics().density;setWillNotDraw(false);setBackgroundColor(Color.TRANSPARENT);}
    private float d(float n){return density*n;}
    private int hit(float x,float y) {
        float c=d(32),w=getWidth(),h=getHeight();
        if(x<c&&y<c)return TL;if(x>w-c&&y<c)return TR;
        if(x<c&&y>h-c)return BL;if(x>w-c&&y>h-c)return BR;
        if(y<d(28))return MOVE;
        if(y>h-d(32))return BAR;
        return 0;
    }
    private Runnable inside,outside;
    void setFocusCallbacks(Runnable inside,Runnable outside){this.inside=inside;this.outside=outside;}
    @Override public boolean dispatchTouchEvent(MotionEvent e){
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN){if(hit(e.getX(),e.getY())==0&&inside!=null)inside.run();else if(outside!=null)outside.run();}
        if(e.getActionMasked()==MotionEvent.ACTION_OUTSIDE&&outside!=null){outside.run();return true;}
        return super.dispatchTouchEvent(e);
    }
    @Override public boolean onInterceptTouchEvent(MotionEvent e) {
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN) {
            active=hit(e.getX(),e.getY());pointer=e.getPointerId(0);
            if(active!=0){gestures.start(active,e.getRawX(),e.getRawY());return true;}
        }
        return active!=0;
    }
    @Override public boolean onTouchEvent(MotionEvent e) {
        if(active==0)return super.onTouchEvent(e);
        if(e.getPointerId(e.getActionIndex())!=pointer && e.getActionMasked()==MotionEvent.ACTION_POINTER_UP)return true;
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_MOVE: if(e.getPointerId(0)==pointer)gestures.move(e.getRawX(),e.getRawY());break;
            case MotionEvent.ACTION_UP:gestures.end(e.getRawX(),e.getRawY(),false);active=0;pointer=-1;performClick();break;
            case MotionEvent.ACTION_CANCEL:gestures.end(e.getRawX(),e.getRawY(),true);active=0;pointer=-1;break;
            case MotionEvent.ACTION_POINTER_UP:gestures.end(e.getRawX(),e.getRawY(),true);active=0;pointer=-1;break;
        }
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
    @Override protected void dispatchDraw(Canvas canvas) {
        float w=getWidth(),h=getHeight(),r=d(26),edge=d(1);
        RectF outer=new RectF(edge,edge,w-edge,h-edge);
        clip.reset();clip.addRoundRect(outer,r,r,Path.Direction.CW);
        int save=canvas.save();canvas.clipPath(clip);paint.setStyle(Paint.Style.FILL);paint.setShader(null);paint.setColor(0x143C4C60);canvas.drawRoundRect(outer,r,r,paint);super.dispatchDraw(canvas);canvas.restoreToCount(save);
        paint.setShader(null);paint.setStyle(Paint.Style.STROKE);paint.setColor(0x33ffffff);paint.setStrokeWidth(d(.8f));canvas.drawRoundRect(outer,r,r,paint);
        // Subtle grip marks on every corner, inside the touch area.
        paint.setColor(0xaaffffff);paint.setStrokeWidth(d(2.2f));paint.setStrokeCap(Paint.Cap.ROUND);
        float m=d(6),s=d(32);
        canvas.drawArc(new RectF(m,m,s,s),190,65,false,paint);
        canvas.drawArc(new RectF(w-s,m,w-m,s),285,65,false,paint);
        canvas.drawArc(new RectF(m,h-s,s,h-m),100,65,false,paint);
        canvas.drawArc(new RectF(w-s,h-s,w-m,h-m),10,65,false,paint);
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xbbeeffff);
        canvas.drawRoundRect(new RectF(w/2-d(22),d(12),w/2+d(22),d(15)),d(2),d(2),paint);
        paint.setColor(0x44000000);canvas.drawRoundRect(new RectF(w/2-d(46),h-d(19),w/2+d(46),h-d(12)),d(4),d(4),paint);
        paint.setColor(0xddffffff);canvas.drawRoundRect(new RectF(w/2-d(43),h-d(18),w/2+d(43),h-d(14)),d(3),d(3),paint);
    }
}
